     Lourah.toggleLog = undefined;
     YConsole.activate(); 
      
     console.log("first intercepted log."); 
     YConsole.docking="bottom"; 
     YConsole.MAX_LOG_ARRAY_LENGTH=20; 
     YConsole.MAX_LOG_STR_LENGTH=300; 
         
     Lourah.YConsoleToggleLog = function() {
     	if (YConsole === undefined) return;
     
     	if (Lourah.toggleLog === undefined) {

     	}
     
    	Lourah.toggleLog = !Lourah.toggleLog;
       
        if(Lourah.toggleLog) {

            YConsole.show();
            }
        else YConsole.hide();
    	}

Lourah.logAndThrow = function(msg) {
	console.log(msg);
	throw(msg);
}

function Lourah() {
	this.version = 1;
	this.release = 0;
	}