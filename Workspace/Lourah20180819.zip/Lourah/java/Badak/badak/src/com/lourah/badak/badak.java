package com.lourah.badak;

public class Badak
{
    public static void main(String[] args)
	{
		//TODO: place you code here
	}
}
