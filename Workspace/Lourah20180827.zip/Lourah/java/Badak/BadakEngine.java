package com.lourah.badak;

public interface BadakEngine {
  public void begin();
  public String eval(String s);
  public void end();
};

