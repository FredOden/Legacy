class jMain extends java.applet.Applet {
   public  void init() {
   	super. init();
   }
   public void paint(Graphics g) {
   	super.paint(g);
       g.drawString("applet launched", 10, 10);
	}
}