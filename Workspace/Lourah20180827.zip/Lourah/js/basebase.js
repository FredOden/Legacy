var Lourah = Lourah || {};
Lourah.base.Class = function() {
	
};

Lourah.bas.Interface = function () {
	
};

Lourah.base.Class.prototype.extends = function(class) {
	
}

Lourah.base.Class.prototye.implements = function(interface) {
	
}