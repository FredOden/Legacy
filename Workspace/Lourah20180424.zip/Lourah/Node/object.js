var Lourah = Lourah || {};
Lourah.nodejs= Lourah.nodejs || {};
Lourah.nodejs.rpc = Lourah.nodejs.rpc || {};


Lourah.nodejs.rpc.Object = {
	
	};
	
	
	
	
module.exports = Lourah.rpc.Object;