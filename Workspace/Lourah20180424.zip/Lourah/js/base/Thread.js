var jscode = function() {
	var i = 1;
	return i;
};

var txt = '(' + jscode.toString() +')()';

console.log("jscode:\""+ txt + "\"");

var Lourah = Lourah || {};
Lourah.base = Lourah.base || {};

Lourah.base.Thread = function (f) {
	  if (typeof f !== "function") throw "Thread requires function";
	  this.f = f;
	  this.w = undefined;
}

Lourah.base.Thread.prototype.run = function() {
	
	if (this.w !== undefined) throw "Thread:" + this.w + ": is already running";
	
   var blob = new Blob(['(' + this.f + ')();'], {type: "application/javascript"});
   console.log("blob:" + blob);
   var url = URL.CreateObjectURL(blob);
   w = new Worker(url);
}

var t = new Lourah.base.Thread(jscode);
//t.run();

{
	
	digit : /[0-9]/,
	
	integer : digit,
	integer : digit integer,
	
	float : integer,
	float : integer '.' integer,
	float : float 'e' sign float,
	sign : void,
	sign : '+',
	sign : '-',
}
