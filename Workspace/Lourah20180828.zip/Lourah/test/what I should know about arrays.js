var p1=[1, 2, 3];

p1.rot = {
	pr:[3, 4, 5],
	p2:[66, 77]
}

console.log(p1);
console.log(p1.rot);
console.log(p1.tr);

console.log(JSON.stringify(p1.rot))