/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function Area3D(a, b ,c) {

    this.setABC(a, b, c);

}


Area3D.prototype.setABC = function(a, b, c) {

    this.a = a;

    this.b = b;

    this.c = c;

    this.geometry = undefined;

};


Area3D.prototype.getGeometry = function() {

    if (this.geometry === undefined) {

     v1 =  (new V3D()).setAB(this.a, this.b).normalize(1);

     v2 = (new V3D()).setAB(this.a, this.c).normalize(1);

     this.geometry = {g: (new P3D()).setXYZ(

             (this.a.x + this.b.x + this.c.x)/3

            ,(this.a.y + this.b.y + this.c.y)/3

            ,(this.a.z + this.b.z + this.c.z)/3)

            ,

        v1: v1,

        v2: v2,

        vOrtho : V3D.vectorProduct(v1, v2)

      };

    }

    return this.geometry;

};


Area3D.prototype.getLambda = function(v) {

    return V3D.scalarProduct(v, this.getGeometry().vOrtho);

};


