var cedric = 2;

function carre(v) {
	return v*v;
}

console.log(carre(carre(cedric)));

