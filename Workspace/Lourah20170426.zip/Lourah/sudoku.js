var board;

board = new Array(9);
for (row = 0; row < 9; row++) {
	board[row] = new Array(9);
}