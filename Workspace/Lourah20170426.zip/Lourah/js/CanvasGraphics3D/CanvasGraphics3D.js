       var canvas;
        var count;
        var haf;
        var canvas3d;
        var c3d;

        var vz = new V3D(0, 0, 1);
        var a = new P3D();
        var b = new P3D();
        var c = new P3D();
        var d = new P3D();
        
        var area = new Area3D(a, b, c);
        var area1 = new Area3D(b, c, d);
        var area2 = new Area3D(a, b, d);
        var area3 = new Area3D(c, d, a);

        function draw()
        {
            count = 0;
            cancelAnimationFrame(haf);
            canvas = document.getElementById("canvas");

            canvas.height = window.innerHeight - canvas.getBoundingClientRect()
                .top - 10;
            canvas.width = window.innerWidth - 20;

            canvas3d = new Canvas3D(canvas);
            c3d = canvas3d.c3d;
            if (c3d === undefined)
            {
                alert("canvas not supported !");
                return;
            }

            haf = requestAnimationFrame(anim1);
        }

        function fillArea3D(c3d, area) {
           var g = area.getGeometry().g;
            var v = new V3D(area.getGeometry().vOrtho)
                .normalize(200);
            var o = P3D.translate(g, v);
            var lambda = area.getLambda(vz);
            c3d.fillStyle = "rgba(" + Math.round(196 - lambda * 128) + "," + Math.round(128 - lambda * 128) + "," + Math.round(196 - lambda * 128) + ",1)";
            c3d.beginPath();
            c3d.area3D(area);
            c3d.closePath();
            c3d.fill();
            
            c3d.fillStyle = "black";
            c3d.fillText3D("x", g);
            
            c3d.strokeStyle = "red";
            c3d.beginPath();
            c3d.polyLine3D(g, o)
            /*
                .polyLine3D(area.a, o)
                .polyLine3D(area.b, o)
                .polyLine3D(area.c, o)
            */
            c3d.stroke();
            
            
            return c3d;
        }

        function scaleText(c3d, p ) {
            c3d.font = "bold " + Math.round(20 * canvas3d.transform3D(p).scale) + "pt sans-serif";
         }
         
         function drawAxis(c3d, size) {
         	c3d.save();
         	c3d.strokeStyle = "green";
            c3d.fillStyle = "black";
            
            c3d.beginPath();

            var O = new P3D();

            scaleText(c3d, O);
            c3d.fillText3D("O", O);
            var I = (new P3D())
                .setXYZ(size, 0, 0);

            c3d.polyLine3D(O, I);
            scaleText(c3d, I);
            c3d.fillText3D("I", I);

            I.setXYZ(0, size, 0);

            c3d.polyLine3D(O, I);
            scaleText(c3d, I);
            c3d.fillText3D("J", I);

            I.setXYZ(0, 0, size);

            c3d.polyLine3D(O, I);
            scaleText(c3d, I);
            c3d.fillText3D("K", I);
            c3d.stroke();
            c3d.restore();
     	}
         
         
        function anim1()
        {
            var count1 = 30;
            canvas3d.setRotation(count/36, count/36, count/36);
            
            a.setSpheric(200, count / 3, 0);
            b.setSpheric(150, 300 - count / 3, 0);
            c.setSpheric(250, 90, count / 3);
            d.setSpheric(100, -135, 50 - count / 3);
            
            var areas = [
               area.setABC(a, b, c),
               area1.setABC(b, c, d),
               area2.setABC(d, a, b),
               area3.setABC(c, d, a)
            ];


           /*
           areas.sort(function(a, b) {
           	return +( a.getZOrder(canvas3d)
                          -b.getZOrder(canvas3d));
           	});
           */
           
           areas.sort(Area3D.zCompare);
           
            
           

            c3d.clearRect(0, 0, canvas.width, canvas.height);
            c3d.save();
            /**/
            drawAxis(c3d, 200);
            
            areas.forEach(function(area) {
            fillArea3D(c3d, area);
            c3d.beginPath();
            c3d.area3D(area);
            c3d.closePath();
            c3d.stroke();
            });
      
            /**/
            c3d.restore();
            count++;
            haf = requestAnimationFrame(anim1);
        }